Shipinjiaoben Collector Helper Installer

Recommended macOS steps:
1. Unzip shipinjiaoben_collector_installer.zip.
2. Right-click Collector_Helper_Installer.app and choose Open.
3. If macOS shows a security prompt, choose Open again.
4. Wait for the Terminal window to finish installation.
5. Return to the website and click the collector check button.

Why right-click Open?
macOS blocks unsigned tools downloaded from a browser. Right-click Open is the standard user-approved way to run a trusted personal installer without a paid Apple Developer ID.

Fallback:
If the app cannot open, right-click Install_Collector_Helper.command from the project scripts folder and choose Open, or remove quarantine with:
xattr -d com.apple.quarantine ~/Downloads/Install_Collector_Helper.command
